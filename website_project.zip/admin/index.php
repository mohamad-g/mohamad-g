<?php
// Include necessary files
require_once '../backend/config/config.php';
require_once '../backend/config/database.php';
require_once '../backend/includes/auth.php';

// Require login
requireLogin('login.php');

// Get current user
$user = getCurrentUser();

// Set language
$lang = $_GET['lang'] ?? DEFAULT_LANGUAGE;
if (!in_array($lang, SUPPORTED_LANGUAGES)) {
    $lang = DEFAULT_LANGUAGE;
}

// Load language strings
$strings = [
    'ar' => [
        'dashboard' => 'لوحة التحكم',
        'welcome' => 'مرحباً بك في لوحة التحكم',
        'profile' => 'الملف الشخصي',
        'articles' => 'المقالات',
        'projects' => 'المشاريع',
        'contact' => 'التواصل',
        'settings' => 'الإعدادات',
        'logout' => 'تسجيل الخروج',
        'stats' => 'إحصائيات',
        'total_articles' => 'إجمالي المقالات',
        'total_projects' => 'إجمالي المشاريع',
        'last_login' => 'آخر تسجيل دخول',
        'quick_actions' => 'إجراءات سريعة',
        'add_article' => 'إضافة مقال جديد',
        'add_project' => 'إضافة مشروع جديد',
        'edit_profile' => 'تعديل الملف الشخصي',
        'recent_activity' => 'النشاط الأخير',
        'view_site' => 'عرض الموقع',
        'change_language' => 'تغيير اللغة',
        'arabic' => 'العربية',
        'german' => 'الألمانية'
    ],
    'de' => [
        'dashboard' => 'Dashboard',
        'welcome' => 'Willkommen im Administrationsbereich',
        'profile' => 'Profil',
        'articles' => 'Artikel',
        'projects' => 'Projekte',
        'contact' => 'Kontakt',
        'settings' => 'Einstellungen',
        'logout' => 'Abmelden',
        'stats' => 'Statistiken',
        'total_articles' => 'Gesamtzahl der Artikel',
        'total_projects' => 'Gesamtzahl der Projekte',
        'last_login' => 'Letzte Anmeldung',
        'quick_actions' => 'Schnellaktionen',
        'add_article' => 'Neuen Artikel hinzufügen',
        'add_project' => 'Neues Projekt hinzufügen',
        'edit_profile' => 'Profil bearbeiten',
        'recent_activity' => 'Letzte Aktivitäten',
        'view_site' => 'Website anzeigen',
        'change_language' => 'Sprache ändern',
        'arabic' => 'Arabisch',
        'german' => 'Deutsch'
    ]
];

// Get strings for current language
$s = $strings[$lang];

// Get statistics
try {
    // Count articles
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM articles WHERE user_id = ? AND language = ?");
    $stmt->execute([$user['id'], $lang]);
    $articlesCount = $stmt->fetchColumn();
    
    // Count projects
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE user_id = ? AND language = ?");
    $stmt->execute([$user['id'], $lang]);
    $projectsCount = $stmt->fetchColumn();
    
    // Get recent activity
    $stmt = $pdo->prepare("
        (SELECT 'article' as type, title, updated_at FROM articles WHERE user_id = ? AND language = ? ORDER BY updated_at DESC LIMIT 3)
        UNION
        (SELECT 'project' as type, title, updated_at FROM projects WHERE user_id = ? AND language = ? ORDER BY updated_at DESC LIMIT 3)
        ORDER BY updated_at DESC LIMIT 5
    ");
    $stmt->execute([$user['id'], $lang, $user['id'], $lang]);
    $recentActivity = $stmt->fetchAll();
} catch (PDOException $e) {
    // Handle database error
    $articlesCount = 0;
    $projectsCount = 0;
    $recentActivity = [];
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $s['dashboard']; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php endif; ?>
    <link rel="stylesheet" href="css/admin-style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h5 class="text-white"><?php echo $s['dashboard']; ?></h5>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> <?php echo $s['dashboard']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user"></i> <?php echo $s['profile']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="articles.php">
                                <i class="fas fa-newspaper"></i> <?php echo $s['articles']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="projects.php">
                                <i class="fas fa-project-diagram"></i> <?php echo $s['projects']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">
                                <i class="fas fa-address-card"></i> <?php echo $s['contact']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog"></i> <?php echo $s['settings']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php?logout=1">
                                <i class="fas fa-sign-out-alt"></i> <?php echo $s['logout']; ?>
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="text-white-50">
                    
                    <div class="dropdown px-3 mb-3">
                        <button class="btn btn-secondary dropdown-toggle w-100" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo $s['change_language']; ?>
                        </button>
                        <ul class="dropdown-menu w-100" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item <?php echo $lang === 'ar' ? 'active' : ''; ?>" href="?lang=ar"><?php echo $s['arabic']; ?></a></li>
                            <li><a class="dropdown-item <?php echo $lang === 'de' ? 'active' : ''; ?>" href="?lang=de"><?php echo $s['german']; ?></a></li>
                        </ul>
                    </div>
                    
                    <div class="px-3 mb-3">
                        <a href="../index.php" class="btn btn-outline-light w-100">
                            <i class="fas fa-external-link-alt"></i> <?php echo $s['view_site']; ?>
                        </a>
                    </div>
                </div>
            </nav>
            
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><?php echo $s['dashboard']; ?></h1>
                </div>
                
                <div class="alert alert-success">
                    <?php echo $s['welcome']; ?>, <?php echo htmlspecialchars($user['username']); ?>!
                </div>
                
                <!-- Statistics -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card text-white bg-primary">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $s['total_articles']; ?></h5>
                                <p class="card-text display-4"><?php echo $articlesCount; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card text-white bg-success">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $s['total_projects']; ?></h5>
                                <p class="card-text display-4"><?php echo $projectsCount; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card text-white bg-info">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $s['last_login']; ?></h5>
                                <p class="card-text"><?php echo date('Y-m-d H:i:s', $_SESSION['last_activity']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5><?php echo $s['quick_actions']; ?></h5>
                            </div>
                            <div class="card-body">
                                <div class="list-group">
                                    <a href="articles.php?action=add" class="list-group-item list-group-item-action">
                                        <i class="fas fa-plus-circle"></i> <?php echo $s['add_article']; ?>
                                    </a>
                                    <a href="projects.php?action=add" class="list-group-item list-group-item-action">
                                        <i class="fas fa-plus-circle"></i> <?php echo $s['add_project']; ?>
                                    </a>
                                    <a href="profile.php" class="list-group-item list-group-item-action">
                                        <i class="fas fa-user-edit"></i> <?php echo $s['edit_profile']; ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Recent Activity -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5><?php echo $s['recent_activity']; ?></h5>
                            </div>
                            <div class="card-body">
                                <ul class="list-group">
                                    <?php if (empty($recentActivity)): ?>
                                    <li class="list-group-item">No recent activity</li>
                                    <?php else: ?>
                                        <?php foreach ($recentActivity as $activity): ?>
                                        <li class="list-group-item">
                                            <i class="fas fa-<?php echo $activity['type'] === 'article' ? 'newspaper' : 'project-diagram'; ?>"></i>
                                            <?php echo htmlspecialchars($activity['title']); ?>
                                            <small class="text-muted float-end"><?php echo date('Y-m-d', strtotime($activity['updated_at'])); ?></small>
                                        </li>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
