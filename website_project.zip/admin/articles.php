<?php
// Include necessary files
require_once '../backend/config/config.php';
require_once '../backend/config/database.php';
require_once '../backend/includes/auth.php';

// Require login
requireLogin('login.php');

// Get current user
$user = getCurrentUser();

// Set language
$lang = $_GET['lang'] ?? DEFAULT_LANGUAGE;
if (!in_array($lang, SUPPORTED_LANGUAGES)) {
    $lang = DEFAULT_LANGUAGE;
}

// Load language strings
$strings = [
    'ar' => [
        'articles' => 'المقالات',
        'all_articles' => 'جميع المقالات',
        'add_article' => 'إضافة مقال جديد',
        'edit_article' => 'تعديل المقال',
        'delete_article' => 'حذف المقال',
        'title' => 'العنوان',
        'summary' => 'الملخص',
        'content' => 'المحتوى',
        'image' => 'الصورة',
        'published_at' => 'تاريخ النشر',
        'actions' => 'الإجراءات',
        'save_changes' => 'حفظ التغييرات',
        'cancel' => 'إلغاء',
        'dashboard' => 'لوحة التحكم',
        'profile' => 'الملف الشخصي',
        'projects' => 'المشاريع',
        'contact' => 'التواصل',
        'settings' => 'الإعدادات',
        'logout' => 'تسجيل الخروج',
        'change_language' => 'تغيير اللغة',
        'arabic' => 'العربية',
        'german' => 'الألمانية',
        'view_site' => 'عرض الموقع',
        'article_added' => 'تمت إضافة المقال بنجاح',
        'article_updated' => 'تم تحديث المقال بنجاح',
        'article_deleted' => 'تم حذف المقال بنجاح',
        'error_occurred' => 'حدث خطأ. يرجى المحاولة مرة أخرى.',
        'no_articles' => 'لا توجد مقالات',
        'edit' => 'تعديل',
        'delete' => 'حذف',
        'confirm_delete' => 'هل أنت متأكد من رغبتك في حذف هذا المقال؟',
        'publish' => 'نشر',
        'unpublish' => 'إلغاء النشر',
        'status' => 'الحالة',
        'published' => 'منشور',
        'draft' => 'مسودة',
        'current_image' => 'الصورة الحالية',
        'change_image' => 'تغيير الصورة',
        'no_image' => 'لا توجد صورة'
    ],
    'de' => [
        'articles' => 'Artikel',
        'all_articles' => 'Alle Artikel',
        'add_article' => 'Neuen Artikel hinzufügen',
        'edit_article' => 'Artikel bearbeiten',
        'delete_article' => 'Artikel löschen',
        'title' => 'Titel',
        'summary' => 'Zusammenfassung',
        'content' => 'Inhalt',
        'image' => 'Bild',
        'published_at' => 'Veröffentlicht am',
        'actions' => 'Aktionen',
        'save_changes' => 'Änderungen speichern',
        'cancel' => 'Abbrechen',
        'dashboard' => 'Dashboard',
        'profile' => 'Profil',
        'projects' => 'Projekte',
        'contact' => 'Kontakt',
        'settings' => 'Einstellungen',
        'logout' => 'Abmelden',
        'change_language' => 'Sprache ändern',
        'arabic' => 'Arabisch',
        'german' => 'Deutsch',
        'view_site' => 'Website anzeigen',
        'article_added' => 'Artikel erfolgreich hinzugefügt',
        'article_updated' => 'Artikel erfolgreich aktualisiert',
        'article_deleted' => 'Artikel erfolgreich gelöscht',
        'error_occurred' => 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.',
        'no_articles' => 'Keine Artikel vorhanden',
        'edit' => 'Bearbeiten',
        'delete' => 'Löschen',
        'confirm_delete' => 'Sind Sie sicher, dass Sie diesen Artikel löschen möchten?',
        'publish' => 'Veröffentlichen',
        'unpublish' => 'Zurückziehen',
        'status' => 'Status',
        'published' => 'Veröffentlicht',
        'draft' => 'Entwurf',
        'current_image' => 'Aktuelles Bild',
        'change_image' => 'Bild ändern',
        'no_image' => 'Kein Bild vorhanden'
    ]
];

// Get strings for current language
$s = $strings[$lang];

// Process form submission
$message = '';
$messageType = '';

// Get articles
try {
    $stmt = $pdo->prepare("SELECT * FROM articles WHERE user_id = ? AND language = ? ORDER BY published_at DESC");
    $stmt->execute([$user['id'], $lang]);
    $articles = $stmt->fetchAll();
} catch (PDOException $e) {
    $message = $s['error_occurred'];
    $messageType = 'danger';
    $articles = [];
}

// Add article
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_article'])) {
    $title = $_POST['title'] ?? '';
    $summary = $_POST['summary'] ?? '';
    $content = $_POST['content'] ?? '';
    $publishedAt = !empty($_POST['published_at']) ? $_POST['published_at'] : null;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO articles (user_id, language, title, summary, content, published_at) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$user['id'], $lang, $title, $summary, $content, $publishedAt]);
        
        $message = $s['article_added'];
        $messageType = 'success';
        
        // Refresh articles data
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE user_id = ? AND language = ? ORDER BY published_at DESC");
        $stmt->execute([$user['id'], $lang]);
        $articles = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Update article
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_article'])) {
    $articleId = $_POST['article_id'] ?? 0;
    $title = $_POST['title'] ?? '';
    $summary = $_POST['summary'] ?? '';
    $content = $_POST['content'] ?? '';
    $publishedAt = !empty($_POST['published_at']) ? $_POST['published_at'] : null;
    
    try {
        $stmt = $pdo->prepare("UPDATE articles SET title = ?, summary = ?, content = ?, published_at = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$title, $summary, $content, $publishedAt, $articleId, $user['id']]);
        
        $message = $s['article_updated'];
        $messageType = 'success';
        
        // Refresh articles data
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE user_id = ? AND language = ? ORDER BY published_at DESC");
        $stmt->execute([$user['id'], $lang]);
        $articles = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Delete article
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_article'])) {
    $articleId = $_POST['article_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM articles WHERE id = ? AND user_id = ?");
        $stmt->execute([$articleId, $user['id']]);
        
        $message = $s['article_deleted'];
        $messageType = 'success';
        
        // Refresh articles data
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE user_id = ? AND language = ? ORDER BY published_at DESC");
        $stmt->execute([$user['id'], $lang]);
        $articles = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Publish/Unpublish article
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_publish'])) {
    $articleId = $_POST['article_id'] ?? 0;
    $publishedAt = $_POST['publish'] === '1' ? date('Y-m-d H:i:s') : null;
    
    try {
        $stmt = $pdo->prepare("UPDATE articles SET published_at = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$publishedAt, $articleId, $user['id']]);
        
        $message = $publishedAt ? $s['article_published'] : $s['article_unpublished'];
        $messageType = 'success';
        
        // Refresh articles data
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE user_id = ? AND language = ? ORDER BY published_at DESC");
        $stmt->execute([$user['id'], $lang]);
        $articles = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Get action
$action = $_GET['action'] ?? 'list';
$articleId = $_GET['id'] ?? 0;

// Get article for edit
$editArticle = null;
if ($action === 'edit' && $articleId) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ? AND user_id = ?");
        $stmt->execute([$articleId, $user['id']]);
        $editArticle = $stmt->fetch();
        
        if (!$editArticle) {
            $action = 'list';
            $message = $s['error_occurred'];
            $messageType = 'danger';
        }
    } catch (PDOException $e) {
        $action = 'list';
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $s['articles']; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php endif; ?>
    <link rel="stylesheet" href="css/admin-style.css">
    <!-- Include CKEditor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h5 class="text-white"><?php echo $s['dashboard']; ?></h5>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> <?php echo $s['dashboard']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user"></i> <?php echo $s['profile']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="articles.php">
                                <i class="fas fa-newspaper"></i> <?php echo $s['articles']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="projects.php">
                                <i class="fas fa-project-diagram"></i> <?php echo $s['projects']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">
                                <i class="fas fa-address-card"></i> <?php echo $s['contact']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog"></i> <?php echo $s['settings']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php?logout=1">
                                <i class="fas fa-sign-out-alt"></i> <?php echo $s['logout']; ?>
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="text-white-50">
                    
                    <div class="dropdown px-3 mb-3">
                        <button class="btn btn-secondary dropdown-toggle w-100" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo $s['change_language']; ?>
                        </button>
                        <ul class="dropdown-menu w-100" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item <?php echo $lang === 'ar' ? 'active' : ''; ?>" href="?lang=ar"><?php echo $s['arabic']; ?></a></li>
                            <li><a class="dropdown-item <?php echo $lang === 'de' ? 'active' : ''; ?>" href="?lang=de"><?php echo $s['german']; ?></a></li>
                        </ul>
                    </div>
                    
                    <div class="px-3 mb-3">
                        <a href="../index.php" class="btn btn-outline-light w-100">
                            <i class="fas fa-external-link-alt"></i> <?php echo $s['view_site']; ?>
                        </a>
                    </div>
                </div>
            </nav>
            
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><?php echo $s['articles']; ?></h1>
                    <?php if ($action === 'list'): ?>
                    <a href="?action=add&lang=<?php echo $lang; ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> <?php echo $s['add_article']; ?>
                    </a>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <?php if ($action === 'list'): ?>
                <!-- Articles List -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><?php echo $s['all_articles']; ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo $s['title']; ?></th>
                                        <th><?php echo $s['published_at']; ?></th>
                                        <th><?php echo $s['status']; ?></th>
                                        <th><?php echo $s['actions']; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($articles)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center"><?php echo $s['no_articles']; ?></td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($articles as $article): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($article['title']); ?></td>
                                            <td><?php echo $article['published_at'] ? date('Y-m-d', strtotime($article['published_at'])) : '-'; ?></td>
                                            <td>
                                                <?php if ($article['published_at']): ?>
                                                <span class="badge bg-success"><?php echo $s['published']; ?></span>
                                                <?php else: ?>
                                                <span class="badge bg-secondary"><?php echo $s['draft']; ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="?action=edit&id=<?php echo $article['id']; ?>&lang=<?php echo $lang; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-edit"></i> <?php echo $s['edit']; ?>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteArticleModal<?php echo $article['id']; ?>">
                                                    <i class="fas fa-trash"></i> <?php echo $s['delete']; ?>
                                                </button>
                                                
                                                <form method="POST" action="" class="d-inline">
                                                    <input type="hidden" name="article_id" value="<?php echo $article['id']; ?>">
                                                    <input type="hidden" name="publish" value="<?php echo $article['published_at'] ? '0' : '1'; ?>">
                                                    <button type="submit" name="toggle_publish" class="btn btn-sm <?php echo $article['published_at'] ? 'btn-warning' : 'btn-success'; ?>">
                                                        <i class="fas <?php echo $article['published_at'] ? 'fa-eye-slash' : 'fa-eye'; ?>"></i> 
                                                        <?php echo $article['published_at'] ? $s['unpublish'] : $s['publish']; ?>
                                                    </button>
                                                </form>
                                                
                                                <!-- Delete Article Modal -->
                                                <div class="modal fade" id="deleteArticleModal<?php echo $article['id']; ?>" tabindex="-1" aria-labelledby="deleteArticleModalLabel<?php echo $article['id']; ?>" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteArticleModalLabel<?php echo $article['id']; ?>"><?php echo $s['delete_article']; ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p><?php echo $s['confirm_delete']; ?></p>
                                                                <p><strong><?php echo htmlspecialchars($article['title']); ?></strong></p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $s['cancel']; ?></button>
                                                                <form method="POST" action="">
                                                                    <input type="hidden" name="article_id" value="<?php echo $article['id']; ?>">
                                                                    <button type="submit" name="delete_article" class="btn btn-danger"><?php echo $s['delete']; ?></button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php elseif ($action === 'add'): ?>
                <!-- Add Article Form -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><?php echo $s['add_article']; ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="title" class="form-label"><?php echo $s['title']; ?></label>
                                <input type="text" class="form-control" id="title" name="title" required>
                            </div>
                            <div class="mb-3">
                                <label for="summary" class="form-label"><?php echo $s['summary']; ?></label>
                                <textarea class="form-control" id="summary" name="summary" rows="3"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="content" class="form-label"><?php echo $s['content']; ?></label>
                                <textarea class="form-control" id="content" name="content" rows="10"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="published_at" class="form-label"><?php echo $s['published_at']; ?></label>
                                <input type="date" class="form-control" id="published_at" name="published_at">
                                <small class="form-text text-muted">Leave empty to save as draft</small>
                            </div>
                            <div class="mb-3">
                                <a href="?lang=<?php echo $lang; ?>" class="btn btn-secondary"><?php echo $s['cancel']; ?></a>
                                <button type="submit" name="add_article" class="btn btn-primary"><?php echo $s['add_article']; ?></button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php elseif ($action === 'edit' && $editArticle): ?>
                <!-- Edit Article Form -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><?php echo $s['edit_article']; ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="article_id" value="<?php echo $editArticle['id']; ?>">
                            <div class="mb-3">
                                <label for="title" class="form-label"><?php echo $s['title']; ?></label>
                                <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($editArticle['title']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="summary" class="form-label"><?php echo $s['summary']; ?></label>
                                <textarea class="form-control" id="summary" name="summary" rows="3"><?php echo htmlspecialchars($editArticle['summary']); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="content" class="form-label"><?php echo $s['content']; ?></label>
                                <textarea class="form-control" id="content" name="content" rows="10"><?php echo htmlspecialchars($editArticle['content']); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="published_at" class="form-label"><?php echo $s['published_at']; ?></label>
                                <input type="date" class="form-control" id="published_at" name="published_at" value="<?php echo $editArticle['published_at'] ? date('Y-m-d', strtotime($editArticle['published_at'])) : ''; ?>">
                                <small class="form-text text-muted">Leave empty to save as draft</small>
                            </div>
                            <div class="mb-3">
                                <a href="?lang=<?php echo $lang; ?>" class="btn btn-secondary"><?php echo $s['cancel']; ?></a>
                                <button type="submit" name="update_article" class="btn btn-primary"><?php echo $s['save_changes']; ?></button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize CKEditor
        CKEDITOR.replace('content', {
            language: '<?php echo $lang; ?>',
            contentsLangDirection: '<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>'
        });
    </script>
</body>
</html>
