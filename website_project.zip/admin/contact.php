<?php
// Include necessary files
require_once '../backend/config/config.php';
require_once '../backend/config/database.php';
require_once '../backend/includes/auth.php';

// Require login
requireLogin('login.php');

// Get current user
$user = getCurrentUser();

// Set language
$lang = $_GET['lang'] ?? DEFAULT_LANGUAGE;
if (!in_array($lang, SUPPORTED_LANGUAGES)) {
    $lang = DEFAULT_LANGUAGE;
}

// Load language strings
$strings = [
    'ar' => [
        'contact' => 'التواصل',
        'contact_info' => 'معلومات التواصل',
        'phone' => 'الهاتف',
        'email' => 'البريد الإلكتروني',
        'address' => 'العنوان',
        'social_media' => 'وسائل التواصل الاجتماعي',
        'add_social_media' => 'إضافة وسيلة تواصل اجتماعي',
        'platform' => 'المنصة',
        'url' => 'الرابط',
        'icon' => 'الأيقونة',
        'order' => 'الترتيب',
        'actions' => 'الإجراءات',
        'save_changes' => 'حفظ التغييرات',
        'cancel' => 'إلغاء',
        'dashboard' => 'لوحة التحكم',
        'profile' => 'الملف الشخصي',
        'articles' => 'المقالات',
        'projects' => 'المشاريع',
        'settings' => 'الإعدادات',
        'logout' => 'تسجيل الخروج',
        'change_language' => 'تغيير اللغة',
        'arabic' => 'العربية',
        'german' => 'الألمانية',
        'view_site' => 'عرض الموقع',
        'contact_updated' => 'تم تحديث معلومات التواصل بنجاح',
        'social_media_added' => 'تمت إضافة وسيلة التواصل الاجتماعي بنجاح',
        'social_media_updated' => 'تم تحديث وسيلة التواصل الاجتماعي بنجاح',
        'social_media_deleted' => 'تم حذف وسيلة التواصل الاجتماعي بنجاح',
        'error_occurred' => 'حدث خطأ. يرجى المحاولة مرة أخرى.',
        'no_social_media' => 'لا توجد وسائل تواصل اجتماعي',
        'edit' => 'تعديل',
        'delete' => 'حذف',
        'confirm_delete' => 'هل أنت متأكد من رغبتك في حذف هذه الوسيلة؟',
        'facebook' => 'فيسبوك',
        'twitter' => 'تويتر',
        'instagram' => 'انستغرام',
        'linkedin' => 'لينكد إن',
        'youtube' => 'يوتيوب',
        'github' => 'جيثب',
        'other' => 'أخرى',
        'platform_name' => 'اسم المنصة',
        'url_placeholder' => 'https://example.com/username',
        'icon_placeholder' => 'fa-facebook',
        'icon_help' => 'اسم أيقونة Font Awesome، مثل: fa-facebook، fa-twitter، إلخ.'
    ],
    'de' => [
        'contact' => 'Kontakt',
        'contact_info' => 'Kontaktinformationen',
        'phone' => 'Telefon',
        'email' => 'E-Mail',
        'address' => 'Adresse',
        'social_media' => 'Soziale Medien',
        'add_social_media' => 'Soziales Medium hinzufügen',
        'platform' => 'Plattform',
        'url' => 'URL',
        'icon' => 'Icon',
        'order' => 'Reihenfolge',
        'actions' => 'Aktionen',
        'save_changes' => 'Änderungen speichern',
        'cancel' => 'Abbrechen',
        'dashboard' => 'Dashboard',
        'profile' => 'Profil',
        'articles' => 'Artikel',
        'projects' => 'Projekte',
        'settings' => 'Einstellungen',
        'logout' => 'Abmelden',
        'change_language' => 'Sprache ändern',
        'arabic' => 'Arabisch',
        'german' => 'Deutsch',
        'view_site' => 'Website anzeigen',
        'contact_updated' => 'Kontaktinformationen erfolgreich aktualisiert',
        'social_media_added' => 'Soziales Medium erfolgreich hinzugefügt',
        'social_media_updated' => 'Soziales Medium erfolgreich aktualisiert',
        'social_media_deleted' => 'Soziales Medium erfolgreich gelöscht',
        'error_occurred' => 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.',
        'no_social_media' => 'Keine sozialen Medien vorhanden',
        'edit' => 'Bearbeiten',
        'delete' => 'Löschen',
        'confirm_delete' => 'Sind Sie sicher, dass Sie dieses soziale Medium löschen möchten?',
        'facebook' => 'Facebook',
        'twitter' => 'Twitter',
        'instagram' => 'Instagram',
        'linkedin' => 'LinkedIn',
        'youtube' => 'YouTube',
        'github' => 'GitHub',
        'other' => 'Andere',
        'platform_name' => 'Plattformname',
        'url_placeholder' => 'https://example.com/username',
        'icon_placeholder' => 'fa-facebook',
        'icon_help' => 'Font Awesome Icon-Name, z.B.: fa-facebook, fa-twitter, usw.'
    ]
];

// Get strings for current language
$s = $strings[$lang];

// Process form submission
$message = '';
$messageType = '';

// Get contact info
try {
    $stmt = $pdo->prepare("SELECT * FROM contact WHERE user_id = ? AND language = ?");
    $stmt->execute([$user['id'], $lang]);
    $contact = $stmt->fetch();
    
    // Get social media
    $stmt = $pdo->prepare("SELECT * FROM social_media WHERE user_id = ? ORDER BY `order` ASC");
    $stmt->execute([$user['id']]);
    $socialMedia = $stmt->fetchAll();
} catch (PDOException $e) {
    $message = $s['error_occurred'];
    $messageType = 'danger';
}

// Update contact info
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_contact'])) {
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    
    try {
        if ($contact) {
            // Update existing contact
            $stmt = $pdo->prepare("UPDATE contact SET phone = ?, email = ?, address = ? WHERE user_id = ? AND language = ?");
            $stmt->execute([$phone, $email, $address, $user['id'], $lang]);
        } else {
            // Insert new contact
            $stmt = $pdo->prepare("INSERT INTO contact (user_id, language, phone, email, address) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user['id'], $lang, $phone, $email, $address]);
        }
        
        $message = $s['contact_updated'];
        $messageType = 'success';
        
        // Refresh contact data
        $stmt = $pdo->prepare("SELECT * FROM contact WHERE user_id = ? AND language = ?");
        $stmt->execute([$user['id'], $lang]);
        $contact = $stmt->fetch();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Add social media
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_social_media'])) {
    $platform = $_POST['platform'] ?? '';
    $url = $_POST['url'] ?? '';
    $icon = $_POST['icon'] ?? '';
    $order = $_POST['order'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO social_media (user_id, platform, url, icon, `order`) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user['id'], $platform, $url, $icon, $order]);
        
        $message = $s['social_media_added'];
        $messageType = 'success';
        
        // Refresh social media data
        $stmt = $pdo->prepare("SELECT * FROM social_media WHERE user_id = ? ORDER BY `order` ASC");
        $stmt->execute([$user['id']]);
        $socialMedia = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Update social media
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_social_media'])) {
    $socialMediaId = $_POST['social_media_id'] ?? 0;
    $platform = $_POST['platform'] ?? '';
    $url = $_POST['url'] ?? '';
    $icon = $_POST['icon'] ?? '';
    $order = $_POST['order'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("UPDATE social_media SET platform = ?, url = ?, icon = ?, `order` = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$platform, $url, $icon, $order, $socialMediaId, $user['id']]);
        
        $message = $s['social_media_updated'];
        $messageType = 'success';
        
        // Refresh social media data
        $stmt = $pdo->prepare("SELECT * FROM social_media WHERE user_id = ? ORDER BY `order` ASC");
        $stmt->execute([$user['id']]);
        $socialMedia = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Delete social media
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_social_media'])) {
    $socialMediaId = $_POST['social_media_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM social_media WHERE id = ? AND user_id = ?");
        $stmt->execute([$socialMediaId, $user['id']]);
        
        $message = $s['social_media_deleted'];
        $messageType = 'success';
        
        // Refresh social media data
        $stmt = $pdo->prepare("SELECT * FROM social_media WHERE user_id = ? ORDER BY `order` ASC");
        $stmt->execute([$user['id']]);
        $socialMedia = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Social media platforms
$platforms = [
    'facebook' => $s['facebook'],
    'twitter' => $s['twitter'],
    'instagram' => $s['instagram'],
    'linkedin' => $s['linkedin'],
    'youtube' => $s['youtube'],
    'github' => $s['github'],
    'other' => $s['other']
];

// Font Awesome icons
$icons = [
    'facebook' => 'fa-facebook',
    'twitter' => 'fa-twitter',
    'instagram' => 'fa-instagram',
    'linkedin' => 'fa-linkedin',
    'youtube' => 'fa-youtube',
    'github' => 'fa-github',
    'other' => 'fa-link'
];
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $s['contact']; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php endif; ?>
    <link rel="stylesheet" href="css/admin-style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h5 class="text-white"><?php echo $s['dashboard']; ?></h5>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> <?php echo $s['dashboard']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user"></i> <?php echo $s['profile']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="articles.php">
                                <i class="fas fa-newspaper"></i> <?php echo $s['articles']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="projects.php">
                                <i class="fas fa-project-diagram"></i> <?php echo $s['projects']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="contact.php">
                                <i class="fas fa-address-card"></i> <?php echo $s['contact']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog"></i> <?php echo $s['settings']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php?logout=1">
                                <i class="fas fa-sign-out-alt"></i> <?php echo $s['logout']; ?>
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="text-white-50">
                    
                    <div class="dropdown px-3 mb-3">
                        <button class="btn btn-secondary dropdown-toggle w-100" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo $s['change_language']; ?>
                        </button>
                        <ul class="dropdown-menu w-100" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item <?php echo $lang === 'ar' ? 'active' : ''; ?>" href="?lang=ar"><?php echo $s['arabic']; ?></a></li>
                            <li><a class="dropdown-item <?php echo $lang === 'de' ? 'active' : ''; ?>" href="?lang=de"><?php echo $s['german']; ?></a></li>
                        </ul>
                    </div>
                    
                    <div class="px-3 mb-3">
                        <a href="../index.php" class="btn btn-outline-light w-100">
                            <i class="fas fa-external-link-alt"></i> <?php echo $s['view_site']; ?>
                        </a>
                    </div>
                </div>
            </nav>
            
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><?php echo $s['contact']; ?></h1>
                </div>
                
                <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <!-- Contact Information -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><?php echo $s['contact_info']; ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="phone" class="form-label"><?php echo $s['phone']; ?></label>
                                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($contact['phone'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label"><?php echo $s['email']; ?></label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($contact['email'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label"><?php echo $s['address']; ?></label>
                                <textarea class="form-control" id="address" name="address" rows="3"><?php echo htmlspecialchars($contact['address'] ?? ''); ?></textarea>
                            </div>
                            <button type="submit" name="update_contact" class="btn btn-primary"><?php echo $s['save_changes']; ?></button>
                        </form>
                    </div>
                </div>
                
                <!-- Social Media -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><?php echo $s['social_media']; ?></h5>
                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addSocialMediaModal">
                            <i class="fas fa-plus"></i> <?php echo $s['add_social_media']; ?>
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo $s['platform']; ?></th>
                                        <th><?php echo $s['url']; ?></th>
                                        <th><?php echo $s['icon']; ?></th>
                                        <th><?php echo $s['order']; ?></th>
                                        <th><?php echo $s['actions']; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($socialMedia)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center"><?php echo $s['no_social_media']; ?></td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($socialMedia as $social): ?>
                                        <tr>
                                            <td>
                                                <?php echo isset($platforms[$social['platform']]) ? $platforms[$social['platform']] : htmlspecialchars($social['platform']); ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo htmlspecialchars($social['url']); ?>" target="_blank">
                                                    <?php echo htmlspecialchars($social['url']); ?>
                                                </a>
                                            </td>
                                            <td>
                                                <i class="fab <?php echo htmlspecialchars($social['icon']); ?>"></i>
                                                <?php echo htmlspecialchars($social['icon']); ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($social['order']); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#editSocialMediaModal<?php echo $social['id']; ?>">
                                                    <i class="fas fa-edit"></i> <?php echo $s['edit']; ?>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteSocialMediaModal<?php echo $social['id']; ?>">
                                                    <i class="fas fa-trash"></i> <?php echo $s['delete']; ?>
                                                </button>
                                                
                                                <!-- Edit Social Media Modal -->
                                                <div class="modal fade" id="editSocialMediaModal<?php echo $social['id']; ?>" tabindex="-1" aria-labelledby="editSocialMediaModalLabel<?php echo $social['id']; ?>" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="editSocialMediaModalLabel<?php echo $social['id']; ?>"><?php echo $s['edit']; ?> <?php echo $s['social_media']; ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form method="POST" action="">
                                                                <div class="modal-body">
                                                                    <input type="hidden" name="social_media_id" value="<?php echo $social['id']; ?>">
                                                                    <div class="mb-3">
                                                                        <label for="platform<?php echo $social['id']; ?>" class="form-label"><?php echo $s['platform']; ?></label>
                                                                        <select class="form-select" id="platform<?php echo $social['id']; ?>" name="platform">
                                                                            <?php foreach ($platforms as $key => $value): ?>
                                                                            <option value="<?php echo $key; ?>" <?php echo $social['platform'] === $key ? 'selected' : ''; ?>><?php echo $value; ?></option>
                                                                            <?php endforeach; ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="url<?php echo $social['id']; ?>" class="form-label"><?php echo $s['url']; ?></label>
                                                                        <input type="url" class="form-control" id="url<?php echo $social['id']; ?>" name="url" value="<?php echo htmlspecialchars($social['url']); ?>" placeholder="<?php echo $s['url_placeholder']; ?>" required>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="icon<?php echo $social['id']; ?>" class="form-label"><?php echo $s['icon']; ?></label>
                                                                        <input type="text" class="form-control" id="icon<?php echo $social['id']; ?>" name="icon" value="<?php echo htmlspecialchars($social['icon']); ?>" placeholder="<?php echo $s['icon_placeholder']; ?>" required>
                                                                        <small class="form-text text-muted"><?php echo $s['icon_help']; ?></small>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="order<?php echo $social['id']; ?>" class="form-label"><?php echo $s['order']; ?></label>
                                                                        <input type="number" class="form-control" id="order<?php echo $social['id']; ?>" name="order" value="<?php echo htmlspecialchars($social['order']); ?>" required>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $s['cancel']; ?></button>
                                                                    <button type="submit" name="update_social_media" class="btn btn-primary"><?php echo $s['save_changes']; ?></button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <!-- Delete Social Media Modal -->
                                                <div class="modal fade" id="deleteSocialMediaModal<?php echo $social['id']; ?>" tabindex="-1" aria-labelledby="deleteSocialMediaModalLabel<?php echo $social['id']; ?>" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteSocialMediaModalLabel<?php echo $social['id']; ?>"><?php echo $s['delete']; ?> <?php echo $s['social_media']; ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p><?php echo $s['confirm_delete']; ?></p>
                                                                <p><strong><?php echo isset($platforms[$social['platform']]) ? $platforms[$social['platform']] : htmlspecialchars($social['platform']); ?></strong></p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $s['cancel']; ?></button>
                                                                <form method="POST" action="">
                                                                    <input type="hidden" name="social_media_id" value="<?php echo $social['id']; ?>">
                                                                    <button type="submit" name="delete_social_media" class="btn btn-danger"><?php echo $s['delete']; ?></button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Add Social Media Modal -->
    <div class="modal fade" id="addSocialMediaModal" tabindex="-1" aria-labelledby="addSocialMediaModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addSocialMediaModalLabel"><?php echo $s['add_social_media']; ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="platform" class="form-label"><?php echo $s['platform']; ?></label>
                            <select class="form-select" id="platform" name="platform">
                                <?php foreach ($platforms as $key => $value): ?>
                                <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="url" class="form-label"><?php echo $s['url']; ?></label>
                            <input type="url" class="form-control" id="url" name="url" placeholder="<?php echo $s['url_placeholder']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="icon" class="form-label"><?php echo $s['icon']; ?></label>
                            <input type="text" class="form-control" id="icon" name="icon" placeholder="<?php echo $s['icon_placeholder']; ?>" required>
                            <small class="form-text text-muted"><?php echo $s['icon_help']; ?></small>
                        </div>
                        <div class="mb-3">
                            <label for="order" class="form-label"><?php echo $s['order']; ?></label>
                            <input type="number" class="form-control" id="order" name="order" value="0" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $s['cancel']; ?></button>
                        <button type="submit" name="add_social_media" class="btn btn-primary"><?php echo $s['add_social_media']; ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-fill icon based on platform selection
        document.addEventListener('DOMContentLoaded', function() {
            const platformSelect = document.getElementById('platform');
            const iconInput = document.getElementById('icon');
            const icons = <?php echo json_encode($icons); ?>;
            
            if (platformSelect && iconInput) {
                platformSelect.addEventListener('change', function() {
                    const platform = this.value;
                    if (icons[platform]) {
                        iconInput.value = icons[platform];
                    }
                });
                
                // Set initial value
                const platform = platformSelect.value;
                if (icons[platform]) {
                    iconInput.value = icons[platform];
                }
            }
            
            // Do the same for edit modals
            <?php foreach ($socialMedia as $social): ?>
            const platformSelect<?php echo $social['id']; ?> = document.getElementById('platform<?php echo $social['id']; ?>');
            const iconInput<?php echo $social['id']; ?> = document.getElementById('icon<?php echo $social['id']; ?>');
            
            if (platformSelect<?php echo $social['id']; ?> && iconInput<?php echo $social['id']; ?>) {
                platformSelect<?php echo $social['id']; ?>.addEventListener('change', function() {
                    const platform = this.value;
                    if (icons[platform]) {
                        iconInput<?php echo $social['id']; ?>.value = icons[platform];
                    }
                });
            }
            <?php endforeach; ?>
        });
    </script>
</body>
</html>
