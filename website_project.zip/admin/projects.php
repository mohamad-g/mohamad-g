<?php
// Include necessary files
require_once '../backend/config/config.php';
require_once '../backend/config/database.php';
require_once '../backend/includes/auth.php';

// Require login
requireLogin('login.php');

// Get current user
$user = getCurrentUser();

// Set language
$lang = $_GET['lang'] ?? DEFAULT_LANGUAGE;
if (!in_array($lang, SUPPORTED_LANGUAGES)) {
    $lang = DEFAULT_LANGUAGE;
}

// Load language strings
$strings = [
    'ar' => [
        'projects' => 'المشاريع',
        'all_projects' => 'جميع المشاريع',
        'add_project' => 'إضافة مشروع جديد',
        'edit_project' => 'تعديل المشروع',
        'delete_project' => 'حذف المشروع',
        'title' => 'العنوان',
        'category' => 'الفئة',
        'description' => 'الوصف',
        'image' => 'الصورة',
        'url' => 'الرابط',
        'technologies' => 'التقنيات',
        'add_technology' => 'إضافة تقنية',
        'technology_name' => 'اسم التقنية',
        'order' => 'الترتيب',
        'actions' => 'الإجراءات',
        'save_changes' => 'حفظ التغييرات',
        'cancel' => 'إلغاء',
        'dashboard' => 'لوحة التحكم',
        'profile' => 'الملف الشخصي',
        'articles' => 'المقالات',
        'contact' => 'التواصل',
        'settings' => 'الإعدادات',
        'logout' => 'تسجيل الخروج',
        'change_language' => 'تغيير اللغة',
        'arabic' => 'العربية',
        'german' => 'الألمانية',
        'view_site' => 'عرض الموقع',
        'project_added' => 'تمت إضافة المشروع بنجاح',
        'project_updated' => 'تم تحديث المشروع بنجاح',
        'project_deleted' => 'تم حذف المشروع بنجاح',
        'technology_added' => 'تمت إضافة التقنية بنجاح',
        'technology_deleted' => 'تم حذف التقنية بنجاح',
        'error_occurred' => 'حدث خطأ. يرجى المحاولة مرة أخرى.',
        'no_projects' => 'لا توجد مشاريع',
        'edit' => 'تعديل',
        'delete' => 'حذف',
        'confirm_delete' => 'هل أنت متأكد من رغبتك في حذف هذا المشروع؟',
        'current_image' => 'الصورة الحالية',
        'change_image' => 'تغيير الصورة',
        'no_image' => 'لا توجد صورة',
        'project_url' => 'رابط المشروع',
        'project_url_placeholder' => 'https://example.com',
        'project_technologies' => 'تقنيات المشروع',
        'no_technologies' => 'لا توجد تقنيات'
    ],
    'de' => [
        'projects' => 'Projekte',
        'all_projects' => 'Alle Projekte',
        'add_project' => 'Neues Projekt hinzufügen',
        'edit_project' => 'Projekt bearbeiten',
        'delete_project' => 'Projekt löschen',
        'title' => 'Titel',
        'category' => 'Kategorie',
        'description' => 'Beschreibung',
        'image' => 'Bild',
        'url' => 'URL',
        'technologies' => 'Technologien',
        'add_technology' => 'Technologie hinzufügen',
        'technology_name' => 'Name der Technologie',
        'order' => 'Reihenfolge',
        'actions' => 'Aktionen',
        'save_changes' => 'Änderungen speichern',
        'cancel' => 'Abbrechen',
        'dashboard' => 'Dashboard',
        'profile' => 'Profil',
        'articles' => 'Artikel',
        'contact' => 'Kontakt',
        'settings' => 'Einstellungen',
        'logout' => 'Abmelden',
        'change_language' => 'Sprache ändern',
        'arabic' => 'Arabisch',
        'german' => 'Deutsch',
        'view_site' => 'Website anzeigen',
        'project_added' => 'Projekt erfolgreich hinzugefügt',
        'project_updated' => 'Projekt erfolgreich aktualisiert',
        'project_deleted' => 'Projekt erfolgreich gelöscht',
        'technology_added' => 'Technologie erfolgreich hinzugefügt',
        'technology_deleted' => 'Technologie erfolgreich gelöscht',
        'error_occurred' => 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.',
        'no_projects' => 'Keine Projekte vorhanden',
        'edit' => 'Bearbeiten',
        'delete' => 'Löschen',
        'confirm_delete' => 'Sind Sie sicher, dass Sie dieses Projekt löschen möchten?',
        'current_image' => 'Aktuelles Bild',
        'change_image' => 'Bild ändern',
        'no_image' => 'Kein Bild vorhanden',
        'project_url' => 'Projekt-URL',
        'project_url_placeholder' => 'https://example.com',
        'project_technologies' => 'Projekt-Technologien',
        'no_technologies' => 'Keine Technologien vorhanden'
    ]
];

// Get strings for current language
$s = $strings[$lang];

// Process form submission
$message = '';
$messageType = '';

// Get projects
try {
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE user_id = ? AND language = ? ORDER BY `order` ASC");
    $stmt->execute([$user['id'], $lang]);
    $projects = $stmt->fetchAll();
} catch (PDOException $e) {
    $message = $s['error_occurred'];
    $messageType = 'danger';
    $projects = [];
}

// Add project
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_project'])) {
    $title = $_POST['title'] ?? '';
    $category = $_POST['category'] ?? '';
    $description = $_POST['description'] ?? '';
    $url = $_POST['url'] ?? '';
    $order = $_POST['order'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO projects (user_id, language, title, category, description, url, `order`) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$user['id'], $lang, $title, $category, $description, $url, $order]);
        
        $message = $s['project_added'];
        $messageType = 'success';
        
        // Refresh projects data
        $stmt = $pdo->prepare("SELECT * FROM projects WHERE user_id = ? AND language = ? ORDER BY `order` ASC");
        $stmt->execute([$user['id'], $lang]);
        $projects = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Update project
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_project'])) {
    $projectId = $_POST['project_id'] ?? 0;
    $title = $_POST['title'] ?? '';
    $category = $_POST['category'] ?? '';
    $description = $_POST['description'] ?? '';
    $url = $_POST['url'] ?? '';
    $order = $_POST['order'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("UPDATE projects SET title = ?, category = ?, description = ?, url = ?, `order` = ? WHERE id = ? AND user_id = ?");
        $stmt->execute([$title, $category, $description, $url, $order, $projectId, $user['id']]);
        
        $message = $s['project_updated'];
        $messageType = 'success';
        
        // Refresh projects data
        $stmt = $pdo->prepare("SELECT * FROM projects WHERE user_id = ? AND language = ? ORDER BY `order` ASC");
        $stmt->execute([$user['id'], $lang]);
        $projects = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Delete project
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_project'])) {
    $projectId = $_POST['project_id'] ?? 0;
    
    try {
        // Delete technologies first (due to foreign key constraint)
        $stmt = $pdo->prepare("DELETE FROM technologies WHERE project_id = ?");
        $stmt->execute([$projectId]);
        
        // Then delete project
        $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ? AND user_id = ?");
        $stmt->execute([$projectId, $user['id']]);
        
        $message = $s['project_deleted'];
        $messageType = 'success';
        
        // Refresh projects data
        $stmt = $pdo->prepare("SELECT * FROM projects WHERE user_id = ? AND language = ? ORDER BY `order` ASC");
        $stmt->execute([$user['id'], $lang]);
        $projects = $stmt->fetchAll();
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Add technology
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_technology'])) {
    $projectId = $_POST['project_id'] ?? 0;
    $name = $_POST['technology_name'] ?? '';
    
    try {
        $stmt = $pdo->prepare("INSERT INTO technologies (project_id, language, name) VALUES (?, ?, ?)");
        $stmt->execute([$projectId, $lang, $name]);
        
        $message = $s['technology_added'];
        $messageType = 'success';
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Delete technology
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_technology'])) {
    $technologyId = $_POST['technology_id'] ?? 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM technologies WHERE id = ?");
        $stmt->execute([$technologyId]);
        
        $message = $s['technology_deleted'];
        $messageType = 'success';
    } catch (PDOException $e) {
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}

// Get action
$action = $_GET['action'] ?? 'list';
$projectId = $_GET['id'] ?? 0;

// Get project for edit
$editProject = null;
$projectTechnologies = [];
if (($action === 'edit' || $action === 'technologies') && $projectId) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ? AND user_id = ?");
        $stmt->execute([$projectId, $user['id']]);
        $editProject = $stmt->fetch();
        
        if (!$editProject) {
            $action = 'list';
            $message = $s['error_occurred'];
            $messageType = 'danger';
        } else {
            // Get technologies for this project
            $stmt = $pdo->prepare("SELECT * FROM technologies WHERE project_id = ? AND language = ?");
            $stmt->execute([$projectId, $lang]);
            $projectTechnologies = $stmt->fetchAll();
        }
    } catch (PDOException $e) {
        $action = 'list';
        $message = $s['error_occurred'];
        $messageType = 'danger';
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $s['projects']; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php endif; ?>
    <link rel="stylesheet" href="css/admin-style.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
                <div class="position-sticky pt-3">
                    <div class="text-center mb-4">
                        <h5 class="text-white"><?php echo $s['dashboard']; ?></h5>
                    </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">
                                <i class="fas fa-tachometer-alt"></i> <?php echo $s['dashboard']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="profile.php">
                                <i class="fas fa-user"></i> <?php echo $s['profile']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="articles.php">
                                <i class="fas fa-newspaper"></i> <?php echo $s['articles']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="projects.php">
                                <i class="fas fa-project-diagram"></i> <?php echo $s['projects']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">
                                <i class="fas fa-address-card"></i> <?php echo $s['contact']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="settings.php">
                                <i class="fas fa-cog"></i> <?php echo $s['settings']; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php?logout=1">
                                <i class="fas fa-sign-out-alt"></i> <?php echo $s['logout']; ?>
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="text-white-50">
                    
                    <div class="dropdown px-3 mb-3">
                        <button class="btn btn-secondary dropdown-toggle w-100" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo $s['change_language']; ?>
                        </button>
                        <ul class="dropdown-menu w-100" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item <?php echo $lang === 'ar' ? 'active' : ''; ?>" href="?lang=ar"><?php echo $s['arabic']; ?></a></li>
                            <li><a class="dropdown-item <?php echo $lang === 'de' ? 'active' : ''; ?>" href="?lang=de"><?php echo $s['german']; ?></a></li>
                        </ul>
                    </div>
                    
                    <div class="px-3 mb-3">
                        <a href="../index.php" class="btn btn-outline-light w-100">
                            <i class="fas fa-external-link-alt"></i> <?php echo $s['view_site']; ?>
                        </a>
                    </div>
                </div>
            </nav>
            
            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2"><?php echo $s['projects']; ?></h1>
                    <?php if ($action === 'list'): ?>
                    <a href="?action=add&lang=<?php echo $lang; ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> <?php echo $s['add_project']; ?>
                    </a>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                
                <?php if ($action === 'list'): ?>
                <!-- Projects List -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><?php echo $s['all_projects']; ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo $s['title']; ?></th>
                                        <th><?php echo $s['category']; ?></th>
                                        <th><?php echo $s['order']; ?></th>
                                        <th><?php echo $s['actions']; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($projects)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center"><?php echo $s['no_projects']; ?></td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($projects as $project): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($project['title']); ?></td>
                                            <td><?php echo htmlspecialchars($project['category']); ?></td>
                                            <td><?php echo htmlspecialchars($project['order']); ?></td>
                                            <td>
                                                <a href="?action=edit&id=<?php echo $project['id']; ?>&lang=<?php echo $lang; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-edit"></i> <?php echo $s['edit']; ?>
                                                </a>
                                                <a href="?action=technologies&id=<?php echo $project['id']; ?>&lang=<?php echo $lang; ?>" class="btn btn-sm btn-success">
                                                    <i class="fas fa-code"></i> <?php echo $s['technologies']; ?>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteProjectModal<?php echo $project['id']; ?>">
                                                    <i class="fas fa-trash"></i> <?php echo $s['delete']; ?>
                                                </button>
                                                
                                                <!-- Delete Project Modal -->
                                                <div class="modal fade" id="deleteProjectModal<?php echo $project['id']; ?>" tabindex="-1" aria-labelledby="deleteProjectModalLabel<?php echo $project['id']; ?>" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteProjectModalLabel<?php echo $project['id']; ?>"><?php echo $s['delete_project']; ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p><?php echo $s['confirm_delete']; ?></p>
                                                                <p><strong><?php echo htmlspecialchars($project['title']); ?></strong></p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $s['cancel']; ?></button>
                                                                <form method="POST" action="">
                                                                    <input type="hidden" name="project_id" value="<?php echo $project['id']; ?>">
                                                                    <button type="submit" name="delete_project" class="btn btn-danger"><?php echo $s['delete']; ?></button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php elseif ($action === 'add'): ?>
                <!-- Add Project Form -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><?php echo $s['add_project']; ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="title" class="form-label"><?php echo $s['title']; ?></label>
                                <input type="text" class="form-control" id="title" name="title" required>
                            </div>
                            <div class="mb-3">
                                <label for="category" class="form-label"><?php echo $s['category']; ?></label>
                                <input type="text" class="form-control" id="category" name="category">
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label"><?php echo $s['description']; ?></label>
                                <textarea class="form-control" id="description" name="description" rows="4"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="url" class="form-label"><?php echo $s['project_url']; ?></label>
                                <input type="url" class="form-control" id="url" name="url" placeholder="<?php echo $s['project_url_placeholder']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="order" class="form-label"><?php echo $s['order']; ?></label>
                                <input type="number" class="form-control" id="order" name="order" value="0" required>
                            </div>
                            <div class="mb-3">
                                <a href="?lang=<?php echo $lang; ?>" class="btn btn-secondary"><?php echo $s['cancel']; ?></a>
                                <button type="submit" name="add_project" class="btn btn-primary"><?php echo $s['add_project']; ?></button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php elseif ($action === 'edit' && $editProject): ?>
                <!-- Edit Project Form -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><?php echo $s['edit_project']; ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <input type="hidden" name="project_id" value="<?php echo $editProject['id']; ?>">
                            <div class="mb-3">
                                <label for="title" class="form-label"><?php echo $s['title']; ?></label>
                                <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($editProject['title']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="category" class="form-label"><?php echo $s['category']; ?></label>
                                <input type="text" class="form-control" id="category" name="category" value="<?php echo htmlspecialchars($editProject['category']); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label"><?php echo $s['description']; ?></label>
                                <textarea class="form-control" id="description" name="description" rows="4"><?php echo htmlspecialchars($editProject['description']); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="url" class="form-label"><?php echo $s['project_url']; ?></label>
                                <input type="url" class="form-control" id="url" name="url" value="<?php echo htmlspecialchars($editProject['url']); ?>" placeholder="<?php echo $s['project_url_placeholder']; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="order" class="form-label"><?php echo $s['order']; ?></label>
                                <input type="number" class="form-control" id="order" name="order" value="<?php echo htmlspecialchars($editProject['order']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <a href="?lang=<?php echo $lang; ?>" class="btn btn-secondary"><?php echo $s['cancel']; ?></a>
                                <button type="submit" name="update_project" class="btn btn-primary"><?php echo $s['save_changes']; ?></button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php elseif ($action === 'technologies' && $editProject): ?>
                <!-- Technologies Management -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><?php echo $s['project_technologies']; ?>: <?php echo htmlspecialchars($editProject['title']); ?></h5>
                        <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addTechnologyModal">
                            <i class="fas fa-plus"></i> <?php echo $s['add_technology']; ?>
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo $s['technology_name']; ?></th>
                                        <th><?php echo $s['actions']; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($projectTechnologies)): ?>
                                    <tr>
                                        <td colspan="2" class="text-center"><?php echo $s['no_technologies']; ?></td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($projectTechnologies as $tech): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($tech['name']); ?></td>
                                            <td>
                                                <form method="POST" action="" class="d-inline">
                                                    <input type="hidden" name="technology_id" value="<?php echo $tech['id']; ?>">
                                                    <button type="submit" name="delete_technology" class="btn btn-sm btn-danger" onclick="return confirm('<?php echo $s['confirm_delete']; ?>')">
                                                        <i class="fas fa-trash"></i> <?php echo $s['delete']; ?>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-3">
                            <a href="?lang=<?php echo $lang; ?>" class="btn btn-secondary"><?php echo $s['cancel']; ?></a>
                        </div>
                    </div>
                </div>
                
                <!-- Add Technology Modal -->
                <div class="modal fade" id="addTechnologyModal" tabindex="-1" aria-labelledby="addTechnologyModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addTechnologyModalLabel"><?php echo $s['add_technology']; ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form method="POST" action="">
                                <div class="modal-body">
                                    <input type="hidden" name="project_id" value="<?php echo $editProject['id']; ?>">
                                    <div class="mb-3">
                                        <label for="technology_name" class="form-label"><?php echo $s['technology_name']; ?></label>
                                        <input type="text" class="form-control" id="technology_name" name="technology_name" required>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $s['cancel']; ?></button>
                                    <button type="submit" name="add_technology" class="btn btn-primary"><?php echo $s['add_technology']; ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
