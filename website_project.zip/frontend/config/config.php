<?php
// Configuration file
define('DB_HOST', 'localhost');
define('DB_NAME', 'personal_website');
define('DB_USER', 'root');
define('DB_PASS', '');

// Language settings
define('DEFAULT_LANGUAGE', 'ar'); // Default language
define('SUPPORTED_LANGUAGES', ['ar', 'de']); // Supported languages

// Site settings
define('SITE_NAME', 'Personal Website');
define('SITE_URL', 'http://localhost/website_project');
define('ADMIN_URL', SITE_URL . '/admin');
define('UPLOADS_DIR', __DIR__ . '/../../uploads');
define('UPLOADS_URL', SITE_URL . '/uploads');

// Session settings
define('SESSION_LIFETIME', 3600); // 1 hour
define('SESSION_NAME', 'personal_website_session');

// Security settings
define('HASH_COST', 10); // Password hashing cost
