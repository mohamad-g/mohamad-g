    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><?php echo $profile['name'] ?? 'Personal Website'; ?></h5>
                    <p><?php echo $profile['title'] ?? ''; ?></p>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $t['contact_me']; ?></h5>
                    <?php if (isset($contactInfo['contact'])): ?>
                    <ul class="list-unstyled">
                        <?php if (!empty($contactInfo['contact']['email'])): ?>
                        <li><i class="fas fa-envelope me-2"></i> <?php echo $contactInfo['contact']['email']; ?></li>
                        <?php endif; ?>
                        <?php if (!empty($contactInfo['contact']['phone'])): ?>
                        <li><i class="fas fa-phone me-2"></i> <?php echo $contactInfo['contact']['phone']; ?></li>
                        <?php endif; ?>
                    </ul>
                    <?php endif; ?>
                </div>
                <div class="col-md-4">
                    <h5><?php echo $t['social_media']; ?></h5>
                    <?php if (isset($contactInfo['social_media']) && !empty($contactInfo['social_media'])): ?>
                    <div class="social-icons">
                        <?php foreach ($contactInfo['social_media'] as $social): ?>
                        <a href="<?php echo $social['url']; ?>" target="_blank" class="text-white me-2">
                            <i class="fab <?php echo $social['icon']; ?> fa-lg"></i>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; <?php echo date('Y'); ?> <?php echo $profile['name'] ?? 'Personal Website'; ?>. <?php echo $t['all_rights_reserved']; ?></p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="admin/login.php" class="text-white text-decoration-none"><?php echo $t['admin_login']; ?></a>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
