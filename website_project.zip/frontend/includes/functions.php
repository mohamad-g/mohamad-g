<?php
// Include configuration
require_once 'config/config.php';

// Language functions
function getCurrentLanguage() {
    $lang = $_GET['lang'] ?? DEFAULT_LANGUAGE;
    if (!in_array($lang, SUPPORTED_LANGUAGES)) {
        $lang = DEFAULT_LANGUAGE;
    }
    return $lang;
}

function getLanguageDirection($lang) {
    return $lang === 'ar' ? 'rtl' : 'ltr';
}

function getLanguageName($lang) {
    $names = [
        'ar' => 'العربية',
        'de' => 'Deutsch'
    ];
    return $names[$lang] ?? $lang;
}

function getTranslations($lang) {
    $translations = [
        'ar' => [
            'home' => 'الرئيسية',
            'about' => 'عني',
            'articles' => 'المقالات',
            'projects' => 'المشاريع',
            'contact' => 'اتصل بي',
            'read_more' => 'اقرأ المزيد',
            'view_project' => 'عرض المشروع',
            'skills' => 'المهارات',
            'experience' => 'الخبرات',
            'education' => 'التعليم',
            'contact_me' => 'تواصل معي',
            'phone' => 'الهاتف',
            'email' => 'البريد الإلكتروني',
            'address' => 'العنوان',
            'social_media' => 'وسائل التواصل الاجتماعي',
            'all_rights_reserved' => 'جميع الحقوق محفوظة',
            'language' => 'اللغة',
            'search' => 'بحث',
            'search_placeholder' => 'ابحث هنا...',
            'no_results' => 'لا توجد نتائج',
            'latest_articles' => 'أحدث المقالات',
            'latest_projects' => 'أحدث المشاريع',
            'technologies_used' => 'التقنيات المستخدمة',
            'published_on' => 'نُشر في',
            'category' => 'الفئة',
            'share' => 'مشاركة',
            'previous' => 'السابق',
            'next' => 'التالي',
            'admin_login' => 'تسجيل دخول المدير'
        ],
        'de' => [
            'home' => 'Startseite',
            'about' => 'Über mich',
            'articles' => 'Artikel',
            'projects' => 'Projekte',
            'contact' => 'Kontakt',
            'read_more' => 'Weiterlesen',
            'view_project' => 'Projekt ansehen',
            'skills' => 'Fähigkeiten',
            'experience' => 'Erfahrung',
            'education' => 'Bildung',
            'contact_me' => 'Kontaktieren Sie mich',
            'phone' => 'Telefon',
            'email' => 'E-Mail',
            'address' => 'Adresse',
            'social_media' => 'Soziale Medien',
            'all_rights_reserved' => 'Alle Rechte vorbehalten',
            'language' => 'Sprache',
            'search' => 'Suche',
            'search_placeholder' => 'Hier suchen...',
            'no_results' => 'Keine Ergebnisse',
            'latest_articles' => 'Neueste Artikel',
            'latest_projects' => 'Neueste Projekte',
            'technologies_used' => 'Verwendete Technologien',
            'published_on' => 'Veröffentlicht am',
            'category' => 'Kategorie',
            'share' => 'Teilen',
            'previous' => 'Zurück',
            'next' => 'Weiter',
            'admin_login' => 'Admin-Login'
        ]
    ];
    
    return $translations[$lang] ?? $translations[DEFAULT_LANGUAGE];
}

// Database connection
function getDbConnection() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die('Database connection failed: ' . $e->getMessage());
        }
    }
    
    return $pdo;
}

// Get profile data
function getProfileData($lang) {
    $pdo = getDbConnection();
    
    try {
        // Get user (assuming there's only one user for now)
        $stmt = $pdo->query("SELECT id FROM users LIMIT 1");
        $user = $stmt->fetch();
        
        if (!$user) {
            return null;
        }
        
        // Get profile data
        $stmt = $pdo->prepare("SELECT * FROM profile WHERE user_id = ? AND language = ?");
        $stmt->execute([$user['id'], $lang]);
        $profile = $stmt->fetch();
        
        if (!$profile) {
            // Fallback to default language if profile not found in requested language
            $stmt = $pdo->prepare("SELECT * FROM profile WHERE user_id = ? AND language = ?");
            $stmt->execute([$user['id'], DEFAULT_LANGUAGE]);
            $profile = $stmt->fetch();
        }
        
        // Get skills
        $stmt = $pdo->prepare("SELECT * FROM skills WHERE user_id = ? AND language = ? ORDER BY `order` ASC");
        $stmt->execute([$user['id'], $lang]);
        $skills = $stmt->fetchAll();
        
        // Get experiences
        $stmt = $pdo->prepare("SELECT * FROM experiences WHERE user_id = ? AND language = ? ORDER BY start_date DESC");
        $stmt->execute([$user['id'], $lang]);
        $experiences = $stmt->fetchAll();
        
        // Get education
        $stmt = $pdo->prepare("SELECT * FROM education WHERE user_id = ? AND language = ? ORDER BY start_date DESC");
        $stmt->execute([$user['id'], $lang]);
        $education = $stmt->fetchAll();
        
        return [
            'profile' => $profile,
            'skills' => $skills,
            'experiences' => $experiences,
            'education' => $education
        ];
    } catch (PDOException $e) {
        return null;
    }
}

// Get articles
function getArticles($lang, $limit = null) {
    $pdo = getDbConnection();
    
    try {
        // Get user (assuming there's only one user for now)
        $stmt = $pdo->query("SELECT id FROM users LIMIT 1");
        $user = $stmt->fetch();
        
        if (!$user) {
            return [];
        }
        
        // Get articles
        $sql = "SELECT * FROM articles WHERE user_id = ? AND language = ? AND published_at IS NOT NULL ORDER BY published_at DESC";
        if ($limit) {
            $sql .= " LIMIT " . (int)$limit;
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$user['id'], $lang]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

// Get article by ID
function getArticleById($id, $lang) {
    $pdo = getDbConnection();
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM articles WHERE id = ? AND language = ? AND published_at IS NOT NULL");
        $stmt->execute([$id, $lang]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        return null;
    }
}

// Get projects
function getProjects($lang, $limit = null) {
    $pdo = getDbConnection();
    
    try {
        // Get user (assuming there's only one user for now)
        $stmt = $pdo->query("SELECT id FROM users LIMIT 1");
        $user = $stmt->fetch();
        
        if (!$user) {
            return [];
        }
        
        // Get projects
        $sql = "SELECT * FROM projects WHERE user_id = ? AND language = ? ORDER BY `order` ASC";
        if ($limit) {
            $sql .= " LIMIT " . (int)$limit;
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$user['id'], $lang]);
        $projects = $stmt->fetchAll();
        
        // Get technologies for each project
        foreach ($projects as &$project) {
            $stmt = $pdo->prepare("SELECT * FROM technologies WHERE project_id = ? AND language = ?");
            $stmt->execute([$project['id'], $lang]);
            $project['technologies'] = $stmt->fetchAll();
        }
        
        return $projects;
    } catch (PDOException $e) {
        return [];
    }
}

// Get project by ID
function getProjectById($id, $lang) {
    $pdo = getDbConnection();
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ? AND language = ?");
        $stmt->execute([$id, $lang]);
        $project = $stmt->fetch();
        
        if ($project) {
            $stmt = $pdo->prepare("SELECT * FROM technologies WHERE project_id = ? AND language = ?");
            $stmt->execute([$project['id'], $lang]);
            $project['technologies'] = $stmt->fetchAll();
        }
        
        return $project;
    } catch (PDOException $e) {
        return null;
    }
}

// Get contact info
function getContactInfo($lang) {
    $pdo = getDbConnection();
    
    try {
        // Get user (assuming there's only one user for now)
        $stmt = $pdo->query("SELECT id FROM users LIMIT 1");
        $user = $stmt->fetch();
        
        if (!$user) {
            return null;
        }
        
        // Get contact info
        $stmt = $pdo->prepare("SELECT * FROM contact WHERE user_id = ? AND language = ?");
        $stmt->execute([$user['id'], $lang]);
        $contact = $stmt->fetch();
        
        if (!$contact) {
            // Fallback to default language if contact not found in requested language
            $stmt = $pdo->prepare("SELECT * FROM contact WHERE user_id = ? AND language = ?");
            $stmt->execute([$user['id'], DEFAULT_LANGUAGE]);
            $contact = $stmt->fetch();
        }
        
        // Get social media
        $stmt = $pdo->prepare("SELECT * FROM social_media WHERE user_id = ? ORDER BY `order` ASC");
        $stmt->execute([$user['id']]);
        $socialMedia = $stmt->fetchAll();
        
        return [
            'contact' => $contact,
            'social_media' => $socialMedia
        ];
    } catch (PDOException $e) {
        return null;
    }
}
