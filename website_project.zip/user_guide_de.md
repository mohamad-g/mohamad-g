# Benutzerhandbuch für das Admin-Panel

## Einführung

Willkommen zum Benutzerhandbuch für das Admin-Panel Ihrer persönlichen Website. Dieses Admin-Panel wurde entwickelt, um Ihnen die einfache Verwaltung Ihrer Website-Inhalte zu ermöglichen, einschließlich persönlicher Informationen, Artikel, Projekte, Kontaktinformationen und Bilder. Die Website unterstützt vollständig Arabisch und Deutsch.

## Zugriff auf das Admin-Panel

1. Gehen Sie zu Ihrer Website-Adresse gefolgt von `/admin`
2. Verwenden Sie die folgenden Anmeldedaten:
   - Benutzername: `admin`
   - Passwort: `admin123`
3. Es wird empfohlen, das Passwort nach der ersten Anmeldung über die Einstellungsseite zu ändern

## Admin-Panel Startseite

Nach der Anmeldung sehen Sie die Admin-Panel Startseite, die Folgendes anzeigt:
- Allgemeine Statistiken zu Ihrer Website (Anzahl der Artikel, Projekte usw.)
- Schnellzugriff auf verschiedene Bereiche
- Ihre letzten Aktualisierungen

## Profilverwaltung

Im Bereich "Profil" können Sie:
1. Persönliche Informationen bearbeiten (Name, Berufsbezeichnung, Kurzbiografie)
2. Fähigkeiten verwalten (hinzufügen, bearbeiten, löschen, sortieren)
3. Berufserfahrungen verwalten (hinzufügen, bearbeiten, löschen)
4. Bildungsweg verwalten (hinzufügen, bearbeiten, löschen)

### Persönliche Informationen bearbeiten
1. Klicken Sie im Seitenmenü auf "Profil"
2. Bearbeiten Sie die gewünschten Felder
3. Klicken Sie auf "Änderungen speichern"

### Fähigkeiten verwalten
1. Gehen Sie zum Abschnitt Fähigkeiten auf der Profilseite
2. Um eine neue Fähigkeit hinzuzufügen, füllen Sie die erforderlichen Felder aus und klicken Sie auf "Hinzufügen"
3. Um eine Fähigkeit zu bearbeiten, klicken Sie auf das Bearbeitungssymbol neben der Fähigkeit
4. Um eine Fähigkeit zu löschen, klicken Sie auf das Löschsymbol neben der Fähigkeit

### Berufserfahrungen und Bildungsweg verwalten
Folgen Sie den gleichen Schritten wie bei der Verwaltung von Fähigkeiten.

## Artikelverwaltung

Im Bereich "Artikel" können Sie:
1. Alle Artikel anzeigen
2. Einen neuen Artikel hinzufügen
3. Einen vorhandenen Artikel bearbeiten
4. Einen Artikel löschen
5. Einen Artikel veröffentlichen/zurückziehen

### Neuen Artikel hinzufügen
1. Klicken Sie auf "Neuen Artikel hinzufügen"
2. Füllen Sie die erforderlichen Felder aus (Titel, Zusammenfassung, Inhalt)
3. Wählen Sie den Veröffentlichungsstatus (veröffentlicht oder Entwurf)
4. Klicken Sie auf "Speichern"

### Artikel bearbeiten
1. Klicken Sie auf das Bearbeitungssymbol neben dem gewünschten Artikel
2. Bearbeiten Sie die gewünschten Felder
3. Klicken Sie auf "Änderungen speichern"

### Artikel löschen
1. Klicken Sie auf das Löschsymbol neben dem gewünschten Artikel
2. Bestätigen Sie das Löschen im Popup-Fenster

## Projektverwaltung

Im Bereich "Projekte" können Sie:
1. Alle Projekte anzeigen
2. Ein neues Projekt hinzufügen
3. Ein vorhandenes Projekt bearbeiten
4. Ein Projekt löschen
5. Die in jedem Projekt verwendeten Technologien verwalten

### Neues Projekt hinzufügen
1. Klicken Sie auf "Neues Projekt hinzufügen"
2. Füllen Sie die erforderlichen Felder aus (Titel, Kategorie, Beschreibung, Link)
3. Fügen Sie verwendete Technologien hinzu
4. Klicken Sie auf "Speichern"

### Technologien verwalten
1. Gehen Sie auf der Projektbearbeitungsseite zum Abschnitt "Verwendete Technologien"
2. Um eine Technologie hinzuzufügen, geben Sie den Namen ein und klicken Sie auf "Hinzufügen"
3. Um eine Technologie zu löschen, klicken Sie auf das Löschsymbol neben der Technologie

## Kontaktverwaltung

Im Bereich "Kontakt" können Sie:
1. Kontaktinformationen bearbeiten (Telefon, E-Mail, Adresse)
2. Social-Media-Konten verwalten (hinzufügen, bearbeiten, löschen)

### Kontaktinformationen bearbeiten
1. Klicken Sie im Seitenmenü auf "Kontakt"
2. Bearbeiten Sie die gewünschten Felder
3. Klicken Sie auf "Änderungen speichern"

### Social-Media-Konten verwalten
1. Gehen Sie zum Abschnitt "Social-Media-Konten"
2. Um ein neues Konto hinzuzufügen, wählen Sie die Plattform, geben Sie den Link ein und klicken Sie auf "Hinzufügen"
3. Um ein Konto zu bearbeiten, klicken Sie auf das Bearbeitungssymbol neben dem Konto
4. Um ein Konto zu löschen, klicken Sie auf das Löschsymbol neben dem Konto

## Bilderverwaltung

Im Bereich "Bilder" können Sie:
1. Profilbild hochladen und verwalten
2. Titelbild hochladen und verwalten
3. Artikelbilder hochladen und verwalten
4. Projektbilder hochladen und verwalten

### Profil- oder Titelbild hochladen
1. Klicken Sie im Seitenmenü auf "Bilder"
2. Klicken Sie unter "Profil- und Titelbilder" auf "Verwalten"
3. Klicken Sie auf "Bild auswählen" und wählen Sie das Bild von Ihrem Gerät
4. Klicken Sie auf "Hochladen"

### Artikelbilder hochladen
1. Klicken Sie im Seitenmenü auf "Bilder"
2. Klicken Sie unter "Artikelbilder" auf "Verwalten"
3. Wählen Sie den Artikel aus dem Dropdown-Menü
4. Klicken Sie auf "Bild auswählen" und wählen Sie das Bild von Ihrem Gerät
5. Klicken Sie auf "Hochladen"

### Projektbilder hochladen
Folgen Sie den gleichen Schritten wie beim Hochladen von Artikelbildern, wählen Sie jedoch "Projektbilder" anstelle von "Artikelbilder".

## Kontoeinstellungen

Im Bereich "Einstellungen" können Sie:
1. Passwort ändern
2. Andere Kontoeinstellungen bearbeiten

### Passwort ändern
1. Klicken Sie im Seitenmenü auf "Einstellungen"
2. Geben Sie Ihr aktuelles Passwort ein
3. Geben Sie Ihr neues Passwort ein und bestätigen Sie es
4. Klicken Sie auf "Passwort ändern"

## Sprache ändern

Sie können die Sprache des Admin-Panels zwischen Arabisch und Deutsch wechseln:
1. Klicken Sie auf das Menü "Sprache ändern" am unteren Rand des Seitenmenüs
2. Wählen Sie die gewünschte Sprache (Arabisch oder Deutsch)

## Abmelden

Um sich vom Admin-Panel abzumelden:
1. Klicken Sie auf "Abmelden" am unteren Rand des Seitenmenüs
2. Sie werden zur Anmeldeseite weitergeleitet

## Tipps und Hinweise

1. Ändern Sie das Standardpasswort bei der ersten Anmeldung
2. Speichern Sie Änderungen nach jeder Bearbeitung
3. Verwenden Sie hochwertige Bilder mit angemessener Größe (weniger als 5 MB)
4. Stellen Sie sicher, dass alle erforderlichen Felder ausgefüllt sind, wenn Sie neue Inhalte hinzufügen
5. Nutzen Sie den erweiterten Texteditor, um Artikel- und Projektinhalte zu formatieren
6. Überprüfen Sie die Website nach wichtigen Änderungen, um sicherzustellen, dass sie korrekt angezeigt werden

## Technischer Support

Wenn Sie Probleme haben oder Fragen haben, kontaktieren Sie uns bitte über:
- E-Mail: support@example.com
- Telefon: +1234567890
